# 提示词模板目录初始化
from backend.config.prompts.prompt_loader import PromptLoader

__all__ = ['PromptLoader']
