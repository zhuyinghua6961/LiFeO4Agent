# 重构代码修复进度报告

## ✅ 已完成的修复

### 1. 提示词文件迁移 ✅
已成功将以下核心提示词文件从 `otherFiles/` 迁移到 `code/backend/config/prompts/`：
- ✅ `system_prompt.txt` - Neo4j Cypher 查询生成提示词
- ✅ `synthesis_prompt_v3.txt` - 精确查询答案合成提示词（含严格数据约束）
- ✅ `semantic_synthesis_prompt_v2.txt` - 语义搜索答案合成提示词（含推断标注）
- ✅ `broad_question_synthesis_prompt.txt` - 宽泛问题答案合成提示词
- ✅ `hybrid_synthesis_prompt.txt` - 混合增强答案合成提示词

### 2. 配置文件完善 ✅
- ✅ 更新 `config.env.example` 添加：
  - DASHSCOPE_API_KEY（阿里百炼，原系统主要使用）
  - VECTOR_DB_PATH, COMMUNITY_VECTOR_DB_PATH
  - BGE_MODEL_PATH, BGE_API_URL
  - PAPERS_DIR
  - SIMILARITY_THRESHOLD_BROAD, SIMILARITY_THRESHOLD_PRECISE
  
- ✅ 更新 `settings.py` 添加：
  - bge_api_url
  - doi_to_pdf_mapping

### 3. 依赖项补充 ✅
- ✅ 更新 `requirements.txt` 添加：
  - sentence-transformers>=2.2.0
  - requests>=2.28.0
  - FlagEmbedding>=1.2.0
  - py2neo>=2021.2.3

### 4. 专家系统补充 ✅
- ✅ 添加 `CommunityExpert` (community_expert.py)
- ✅ 更新 experts 模块的 __init__.py

## 🔄 需要继续的修复（核心功能缺失）

### 高优先级（系统无法正常运行）

#### 1. 添加缺失的核心组件
需要从 otherFiles 移植以下关键组件：
- ❌ `CommanderAgent` - 决策指挥官（智能判断查询模式）
- ❌ `HybridQueryAgent` - 混合查询代理（Neo4j + 语义搜索结合）
- ❌ `GenerationDrivenRAG` - 生成驱动检索系统（两阶段RAG）
- ❌ `DualRetrievalAgent` - 双召回检索代理
- ❌ `Neo4jTwoStageOptimizer` - Neo4j 两阶段查询优化器
- ❌ `IntegratedAgent` - 集成智能代理（统一入口）

#### 2. 重构 API routes.py 的 /ask_stream 端点
当前问题：
- ❌ 绕过了服务层，直接操作 Repository
- ❌ 没有使用专家系统
- ❌ 硬编码了大量业务逻辑
- ❌ PDF 匹配逻辑低效

需要改为：
- ✅ 使用 IntegratedAgent 统一处理
- ✅ 智能路由到合适的专家系统
- ✅ 使用服务层封装业务逻辑
- ✅ 支持多种查询模式（PDF直接查询、生成驱动检索等）

#### 3. 专家系统功能增强
需要增强现有专家系统：

**QueryExpert 需要添加**：
- ❌ PDF 原文加载和数据补充
- ❌ 两阶段查询优化
- ❌ 材料类型过滤验证
- ❌ 单位检查和验证

**SemanticExpert 需要添加**：
- ❌ 相似度过滤（动态阈值）
- ❌ PDF 原文加载
- ❌ 宽泛问题处理（方案五：LLM框架+文献补充）

#### 4. 服务层功能完善
**LLMService 需要添加**：
- ❌ 加载和管理提示词模板的方法
- ❌ 提示词模板的缓存机制

**VectorService 需要添加**：
- ❌ aggregate_knowledge 方法（聚合文献和社区知识）
- ❌ 关键词匹配降级方案

**Neo4jService 需要添加**：
- ❌ 两阶段查询优化支持
- ❌ 查询结果验证（单位检查、材料类型检查）

### 中优先级（功能完整性）

#### 5. 添加工具类模块
需要从 otherFiles 添加：
- ❌ `pdf_loader.py` 的完整实现（PDF 提取、参考文献排除等）
- ❌ `cypher_utils.py` 的工具函数
- ❌ `formatters.py` 的格式化工具

#### 6. 实现单例服务管理
当前问题：
- ❌ main.py 中初始化一次
- ❌ routes.py 中又初始化一次（懒加载）
- ❌ 每个端点可能重复创建实例

需要改为：
- ✅ 统一的服务管理器
- ✅ 全局单例模式
- ✅ 避免重复初始化

#### 7. 添加其他缺失端点
原系统有但重构后缺失：
- ❌ `/upload` - PDF 上传端点
- ❌ `/pdf/view` - PDF 查看端点
- ❌ `/integrated_query` - 集成查询端点（使用 IntegratedAgent）

### 低优先级（优化和完善）

#### 8. 添加翻译缓存机制
原系统有但重构后缺失：
- ❌ TranslationCache 类
- ❌ SmartTranslator 类

#### 9. 添加上下文解析
原系统支持多轮对话上下文理解：
- ❌ need_context_resolution() 函数
- ❌ resolve_context_question() 函数

#### 10. 添加 PDF 智能匹配
原系统的高级功能：
- ❌ DOI 到 PDF 的映射缓存
- ❌ 文件名智能匹配
- ❌ PDF 内容预览

## 📝 修复建议和优先级

### 立即修复（阻塞性问题）
1. **添加 IntegratedAgent**（最重要）
   - 这是统一入口，所有查询都应该通过它
   - 包含智能路由逻辑
   - 协调各个专家系统

2. **重构 /ask_stream 端点**
   - 使用 IntegratedAgent 替代当前的硬编码逻辑
   - 恢复流式输出的完整流程

3. **完善 QueryExpert 和 SemanticExpert**
   - 添加 PDF 原文加载
   - 添加答案合成逻辑
   - 使用正确的提示词模板

### 短期修复（1-2天）
4. 添加 GenerationDrivenRAG
5. 添加 HybridQueryAgent 和 CommanderAgent
6. 实现单例服务管理
7. 完善工具类模块

### 中期优化（3-7天）
8. 添加翻译缓存
9. 添加上下文解析
10. 添加其他端点（upload, pdf/view 等）

## 🔍 关键修复示例

### 示例1: QueryExpert 需要添加的核心方法

```python
def _synthesize_answer(self, user_question: str, query_result: List[Dict]) -> str:
    """答案合成（使用 synthesis_prompt_v3.txt）"""
    # 1. 从查询结果中提取 DOI
    # 2. 加载 PDF 原文
    # 3. 使用 synthesis_prompt_v3.txt 构建提示词
    # 4. 调用 LLM 生成答案
    # 5. 返回答案
    
def _load_pdf_by_doi(self, doi: str) -> Optional[str]:
    """根据 DOI 加载 PDF 原文"""
    # 1. 从 doi_to_pdf_mapping.json 查找
    # 2. 使用 PDFLoader 提取文本
    # 3. 返回 PDF 内容
```

### 示例2: /ask_stream 应该改成的样子

```python
@api.route('/ask_stream', methods=['POST'])
def ask_question_stream():
    def generate():
        # 1. 获取问题
        question = data.get('question')
        
        # 2. 使用 IntegratedAgent（不是直接操作 Repository）
        integrated_agent = get_integrated_agent()
        
        # 3. 智能路由和查询
        for chunk in integrated_agent.query_stream(question):
            yield f"data: {json.dumps(chunk)}\n\n"
    
    return Response(generate(), mimetype='text/event-stream')
```

## 📊 修复工作量估算

| 任务 | 预计时间 | 难度 | 优先级 |
|------|---------|------|--------|
| 添加 IntegratedAgent | 2-3h | 中 | 🔴 最高 |
| 重构 /ask_stream | 2-3h | 中 | 🔴 最高 |
| 完善 QueryExpert | 3-4h | 高 | 🔴 最高 |
| 完善 SemanticExpert | 2-3h | 中 | 🔴 最高 |
| 添加 GenerationDrivenRAG | 4-5h | 高 | 🟡 高 |
| 添加其他核心组件 | 3-4h | 中 | 🟡 高 |
| 实现单例管理 | 1-2h | 低 | 🟡 高 |
| 完善工具类 | 2-3h | 低 | 🟢 中 |
| 添加其他端点 | 2-3h | 低 | 🟢 中 |
| 翻译缓存等优化 | 2-3h | 低 | ⚪ 低 |

**总计**: 约 23-33 小时工作量

## ✅ 下一步行动计划

1. 立即创建 `IntegratedAgent` 类
2. 从 otherFiles/integrated_agent.py 移植核心逻辑
3. 重构 routes.py 的 /ask_stream 使用 IntegratedAgent
4. 完善 QueryExpert 添加 PDF 加载和答案合成
5. 完善 SemanticExpert 添加相似度过滤和 PDF 加载
6. 测试核心流程是否正常工作
7. 逐步添加其他缺失组件

## 📌 注意事项

1. **不要破坏现有功能**：在添加新功能时，确保不影响已有的端点
2. **保持分层架构**：遵守 Controller → Service → Repository 的分层原则
3. **使用提示词模板**：所有 LLM 调用都应该使用 config/prompts/ 中的模板
4. **测试驱动**：每完成一个组件，立即测试其功能
5. **日志记录**：添加详细的日志，方便调试和追踪问题
