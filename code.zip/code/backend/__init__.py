"""
Material Knowledge Base Backend
材料知识库后端服务
"""

__version__ = "1.0.0"
