"""
API层
RESTful API端点定义
"""

from .routes import api

__all__ = ['api']
